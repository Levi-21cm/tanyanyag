module Kosar2004CLI {
    exports hu.katolikuskeri.kosar2004cli;
}