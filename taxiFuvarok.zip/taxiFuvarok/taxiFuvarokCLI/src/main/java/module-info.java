module taxiFuvarokCLI {
    exports hu.katolikuskeri.taxifuvarok.cli;
}