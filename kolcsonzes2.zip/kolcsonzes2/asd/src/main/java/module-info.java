module asd {
    exports hu.katolikuskeri.keri14c.cl;
}